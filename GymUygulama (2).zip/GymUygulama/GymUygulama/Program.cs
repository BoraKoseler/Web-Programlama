﻿using FitnessApp.Data; // Proje ad?n?z farkl?ysa onu yaz?n
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Identity;


namespace GymUygulama
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);
            // Veritaban? servisini ekliyoruz
            builder.Services.AddDbContext<ApplicationDbContext>(options =>
                options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

            //builder.Services.AddDefaultIdentity<IdentityUser>(options => options.SignIn.RequireConfirmedAccount = true).AddEntityFrameworkStores<ApplicationDbContext>();

            // Identity Ayarları (Rolleri Ekledik ve Şifre Kuralını Gevşettik)
            builder.Services.AddIdentity<IdentityUser, IdentityRole>(options =>
            {
                // Şifre kuralları (Ödevdeki "sau" şifresi için bunları kapatıyoruz)
                options.Password.RequireDigit = false;
                options.Password.RequireLowercase = false;
                options.Password.RequireUppercase = false;
                options.Password.RequireNonAlphanumeric = false;
                options.Password.RequiredLength = 3; // En az 3 karakter ("sau" için)
            })
            .AddEntityFrameworkStores<ApplicationDbContext>()
            .AddDefaultTokenProviders();

            // Add services to the container.
            builder.Services.AddControllersWithViews();

            builder.Services.AddRazorPages();

            builder.Services.AddEndpointsApiExplorer();

            builder.Services.AddSwaggerGen();

            // E-posta servisi hatasını çözmek için:
            builder.Services.AddSingleton<Microsoft.AspNetCore.Identity.UI.Services.IEmailSender, EmailSender>();

            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (!app.Environment.IsDevelopment())
            {
                app.UseExceptionHandler("/Home/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }

            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
            }

            app.UseHttpsRedirection();
            app.UseStaticFiles();

            app.UseRouting();

            app.UseAuthorization();

            app.MapControllerRoute(
                name: "default",
                pattern: "{controller=Home}/{action=Index}/{id?}");

            app.MapRazorPages();

            // Veritabanı Seed İşlemi (Otomatik Admin Ekleme)
            using (var scope = app.Services.CreateScope())
            {
                var services = scope.ServiceProvider;
                DbSeeder.SeedRolesAndAdminAsync(services).Wait();
            }

            app.Run();
        }
    }
}
