﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FitnessApp.Data;
using FitnessApp.Models;

namespace GymUygulama.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GymServicesApiController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public GymServicesApiController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: api/GymServicesApi
        [HttpGet]
        public async Task<ActionResult<IEnumerable<GymService>>> GetGymServices()
        {
            return await _context.GymServices.ToListAsync();
        }

        // GET: api/GymServicesApi/5
        [HttpGet("{id}")]
        public async Task<ActionResult<GymService>> GetGymService(int id)
        {
            var gymService = await _context.GymServices.FindAsync(id);

            if (gymService == null)
            {
                return NotFound();
            }

            return gymService;
        }

        // PUT: api/GymServicesApi/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutGymService(int id, GymService gymService)
        {
            if (id != gymService.ServiceId)
            {
                return BadRequest();
            }

            _context.Entry(gymService).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!GymServiceExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/GymServicesApi
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<GymService>> PostGymService(GymService gymService)
        {
            _context.GymServices.Add(gymService);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetGymService", new { id = gymService.ServiceId }, gymService);
        }

        // DELETE: api/GymServicesApi/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteGymService(int id)
        {
            var gymService = await _context.GymServices.FindAsync(id);
            if (gymService == null)
            {
                return NotFound();
            }

            _context.GymServices.Remove(gymService);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool GymServiceExists(int id)
        {
            return _context.GymServices.Any(e => e.ServiceId == id);
        }
    }
}
