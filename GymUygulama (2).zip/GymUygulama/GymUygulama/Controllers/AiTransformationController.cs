﻿using Microsoft.AspNetCore.Mvc;
using System.Text;
using System.Text.Json; // System.Text.Json kütüphanesini kullanıyoruz

namespace FitnessApp.Controllers
{
    public class AiTransformationController : Controller
    {
        // 1. ADIM: Google AI Studio'dan aldığınız API Anahtarını buraya yapıştırın
        private readonly string _apiKey = "AIzaSyBa0lqsHtV6xY_SCxJV_UCf55jOBIYhJaM";
        private readonly HttpClient _httpClient;

        public AiTransformationController()
        {
            _httpClient = new HttpClient();
        }

        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> GenerateTransformation(IFormFile photo)
        {
            if (photo == null || photo.Length == 0)
                return View("Index");

            // Resmi Base64 formatına çeviriyoruz
            using var memoryStream = new MemoryStream();
            await photo.CopyToAsync(memoryStream);
            byte[] imageBytes = memoryStream.ToArray();
            string base64Image = Convert.ToBase64String(imageBytes);

            // 2. ADIM: Gemini 2.0 Flash Experimental URL'i
            // Dikkat: Model ismi URL'de 'models/gemini-2.0-flash-exp' olarak geçiyor.
            var apiUrl = $"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash-exp:generateContent?key={_apiKey}";

            // 3. ADIM: İstek Gövdesini (JSON) Hazırlama
            // Hem metin (prompt) hem de resmi (inline_data) aynı anda gönderiyoruz.
            var requestBody = new
            {
                contents = new[]
                {
                    new
                    {
                        parts = new object[]
                        {
                            new { text = "This is a photo of a person. Generate a text description of how this person would look after 6 months of intense gym training and healthy diet. Describe the physical changes in detail." }, // Şimdilik metin dönüşü istiyoruz, görsel üretimi için 'Imagen' modeli gerekebilir.
                            new
                            {
                                inline_data = new
                                {
                                    mime_type = "image/jpeg", // Yüklenen dosya tipine göre dinamik olabilir
                                    data = base64Image
                                }
                            }
                        }
                    }
                }
            };

            var jsonContent = new StringContent(JsonSerializer.Serialize(requestBody), Encoding.UTF8, "application/json");

            // İsteği Gönder
            var response = await _httpClient.PostAsync(apiUrl, jsonContent);

            if (response.IsSuccessStatusCode)
            {
                var responseString = await response.Content.ReadAsStringAsync();

                // Gelen JSON cevabını parçalayıp sonucu alıyoruz
                using var doc = JsonDocument.Parse(responseString);
                try
                {
                    var resultText = doc.RootElement
                        .GetProperty("candidates")[0]
                        .GetProperty("content")
                        .GetProperty("parts")[0]
                        .GetProperty("text")
                        .GetString();

                    ViewBag.ResultText = resultText;
                    ViewBag.OriginalImage = base64Image; // Orijinal resmi de ekranda gösterelim
                }
                catch
                {
                    ViewBag.Error = "Cevap okunamadı.";
                }
            }
            else
            {
                ViewBag.Error = "API Hatası: " + response.ReasonPhrase;
            }

            return View("Index");
        }
    }
}