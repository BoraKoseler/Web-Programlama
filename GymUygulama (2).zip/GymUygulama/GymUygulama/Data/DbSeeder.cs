﻿using Microsoft.AspNetCore.Identity;
using FitnessApp.Models;

namespace FitnessApp.Data
{
    public static class DbSeeder
    {
        public static async Task SeedRolesAndAdminAsync(IServiceProvider service)
        {
            // Kullanıcı ve Rol yönetimi servislerini çağırıyoruz
            var userManager = service.GetService<UserManager<IdentityUser>>();
            var roleManager = service.GetService<RoleManager<IdentityRole>>();

            // 1. Önce Rolleri Oluşturuyoruz (Admin ve Member)
            await roleManager.CreateAsync(new IdentityRole("Admin"));
            await roleManager.CreateAsync(new IdentityRole("Member"));

            // 2. Admin Kullanıcısını Oluşturuyoruz
            var adminEmail = "B231210060@sakarya.edu.tr";
            var adminUser = await userManager.FindByEmailAsync(adminEmail);

            if (adminUser == null)
            {
                adminUser = new IdentityUser
                {
                    UserName = adminEmail,
                    Email = adminEmail,
                    EmailConfirmed = true
                };

                // Şifreyi "sau" olarak belirliyoruz (Program.cs ayarı gerekli)
                var result = await userManager.CreateAsync(adminUser, "sau");

                if (result.Succeeded)
                {
                    // Kullanıcı oluştuysa ona Admin rolünü veriyoruz
                    await userManager.AddToRoleAsync(adminUser, "Admin");
                }
            }
        }
    }
}