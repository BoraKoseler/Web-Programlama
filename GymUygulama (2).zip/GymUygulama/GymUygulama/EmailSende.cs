﻿using Microsoft.AspNetCore.Identity.UI.Services;

namespace GymUygulama // Burası projenizin adıyla aynı olmalı
{
    // Bu sınıf "Mail gönderiyormuş gibi" yapıp aslında hiçbir şey yapmaz.
    // Böylece hata almaktan kurtuluruz.
    public class EmailSender : IEmailSender
    {
        public Task SendEmailAsync(string email, string subject, string htmlMessage)
        {
            // Burası boş, yani mail atma işlemi başarılıymış gibi davranır.
            return Task.CompletedTask;
        }
    }
}