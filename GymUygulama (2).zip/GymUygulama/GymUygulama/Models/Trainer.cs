﻿using System.ComponentModel.DataAnnotations;

namespace FitnessApp.Models
{
    public class Trainer
    {
        [Key]
        public int TrainerId { get; set; }

        [Required(ErrorMessage = "Ad Soyad zorunludur.")]
        [Display(Name = "Antrenör Adı")]
        public string FullName { get; set; }

        [Display(Name = "Uzmanlık Alanı")]
        public string Expertise { get; set; } // Örn: Kilo Verme, Kas Yapma

        // İlişkiler
        // Bir antrenörün birden fazla randevusu olabilir
        public ICollection<Appointment>? Appointments { get; set; }

        // Bir antrenör birden fazla hizmet verebilir (Basitleştirilmiş ilişki)
        public int GymServiceId { get; set; }
        public GymService? GymService { get; set; }
    }
}