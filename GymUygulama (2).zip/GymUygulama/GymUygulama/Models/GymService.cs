﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


namespace FitnessApp.Models
{
    public class GymService
    {
        [Key]
        public int ServiceId { get; set; }

        [Required(ErrorMessage = "Hizmet adı zorunludur.")]
        [Display(Name = "Hizmet Adı")]
        public string Name { get; set; } // Örn: Yoga, Pilates

        [Display(Name = "Süre (Dakika)")]
        public int DurationMinutes { get; set; } // Örn: 60 dk

        [Column(TypeName = "decimal(18, 2)")]
        [Display(Name = "Ücret")] 
        public decimal Price { get; set; } // Örn: 500 TL

        // Bir hizmeti birden çok antrenör verebilir (İlişki)
        // Soru işareti (?) ekliyoruz ki sistem bunun boş olmasına izin versin
        public ICollection<Trainer>? Trainers { get; set; }
    }
}