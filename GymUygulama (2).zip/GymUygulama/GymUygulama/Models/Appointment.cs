﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.AspNetCore.Identity;

namespace FitnessApp.Models
{
    public class Appointment
    {
        [Key]
        public int AppointmentId { get; set; }

        [Required(ErrorMessage = "Tarih seçimi zorunludur.")]
        [Display(Name = "Randevu Tarihi")]
        public DateTime Date { get; set; }

        // Kullanıcı ID'si (Identity sisteminde ID'ler string yani metindir)
        public string? UserId { get; set; }

        [ForeignKey("UserId")]
        public IdentityUser? User { get; set; }

        [Display(Name = "Durum")]
        public string? Status { get; set; } = "Bekliyor"; // Bekliyor, Onaylandı, İptal

        // İlişkiler
        public int TrainerId { get; set; }
        public Trainer? Trainer { get; set; }

    }
}